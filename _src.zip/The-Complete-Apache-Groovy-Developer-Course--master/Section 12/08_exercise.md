Use a REST Service

I want you to find a public REST service and try to use it. I would try and find one where you don't have to authenticate as it will be a little bit easier to consume. What public REST services did you find? What ones are your favorites?
