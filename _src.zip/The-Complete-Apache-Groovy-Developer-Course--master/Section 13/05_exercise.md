Database Programming with Groovy

- Create a script that connects to any type of database
- Create a new table in that database with a few fields
- Write some initial data to that table (only a few rows needed)

Working With Files

- Using the same script read the rows from that table
- Take the result of that read and write these rows out to a CSV file
